# Quectel Connect Manager
For those who struggle to get the sources. Their support gave me the sources.
## Version 1.1.45 for Linux&Android
This is the version 1.1.45 of the **Connect Manager** from Quectel.
## Makefile
The Makefile was adapted to work with the Yocto/Poky build envrionnement (not much done but 'as is', it wasn't working).